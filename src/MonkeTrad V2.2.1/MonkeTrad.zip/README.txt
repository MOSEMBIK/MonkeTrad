# README.txt

MonkeTrad V2.2.1
Developped by MOSEMBIK

# Something went wrong ?
	# Error type : Failed to execute script MonkeTrad
		 This error should come if you start
		MonkeTrad.exe in a file that doesn't include
		icon.ico in root.
		
		Fix methode :
			 Use a shortcut and let all originals
			files somewhere on your computer.

	# An other bug ?
		 Contact me on mosembik.dev@gmail.com.